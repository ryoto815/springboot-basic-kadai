package com.example.springpractice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springpractice.entity.ToDo;

public interface ToDoRepository extends JpaRepository<ToDo, Integer>{

	public List<ToDo>findAll();
}
