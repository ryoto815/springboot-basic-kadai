package com.example.springpractice.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.springpractice.entity.ToDo;
import com.example.springpractice.service.ToDoService;

@Controller
public class ToDoController {
	private final ToDoService toDoService;
	
	public ToDoController(ToDoService toDoService) {
		super();
		this.toDoService = toDoService;
	}

	@GetMapping("/todo")
	public String showToDoList(Model model) {
		List<ToDo>toDoList=toDoService.findAll();
		model.addAttribute("toDoList",toDoList);
		return "todoView";
	}
}
