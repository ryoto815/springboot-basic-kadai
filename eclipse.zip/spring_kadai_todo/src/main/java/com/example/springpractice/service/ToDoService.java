package com.example.springpractice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.springpractice.entity.ToDo;
import com.example.springpractice.repository.ToDoRepository;

@Service
public class ToDoService {
	private final ToDoRepository toDoRepository;
	
	public ToDoService(ToDoRepository toDoRepository) {
		super();
		this.toDoRepository = toDoRepository;
	}

	public List<ToDo> findAll() {
		return toDoRepository.findAll();
	}
}
